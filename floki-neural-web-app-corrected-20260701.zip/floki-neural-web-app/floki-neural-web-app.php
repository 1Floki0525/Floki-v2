<?php
/**
 * Plugin Name: Floki Neural Web App
 * Description: Invite-only Floki Neural Interface at the authenticated site root.
 * Version: 2026.07.01.030000
 * Author: Floki
 */
defined('ABSPATH') || exit;

final class Floki_Neural_Web_App {
    const FLAG = 'floki_neural_app';
    const PATH = 'floki_neural_path';
    const KEY_OPTION = 'floki_signing_key';
    const PUBKEY_OPTION = 'floki_signing_pubkey';

    static function boot() {
        add_action('init', [__CLASS__, 'rewrite']);
        add_filter('query_vars', [__CLASS__, 'vars']);
        add_filter('redirect_canonical', [__CLASS__, 'canonical'], 10, 2);
        add_action('template_redirect', [__CLASS__, 'serve'], -1000);
        add_filter('option_users_can_register', '__return_false');
        add_action('login_form_register', [__CLASS__, 'back_home']);
        add_action('login_form_lostpassword', [__CLASS__, 'back_home']);
        add_filter('login_redirect', [__CLASS__, 'login_redirect'], 10, 3);
        add_action('user_register', [__CLASS__, 'approve_admin_user'], 20);
        add_action('init', [__CLASS__, 'remove_signup'], 100);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    static function activate() {
        self::rewrite();
        update_option('users_can_register', 0);
        self::ensure_keypair();
        flush_rewrite_rules(false);
    }

    static function deactivate() {
        flush_rewrite_rules(false);
    }

    static function ensure_keypair() {
        if (!extension_loaded('sodium')) return;
        $keys = get_option(self::KEY_OPTION);
        if ($keys && isset($keys['sk']) && strlen(base64_decode($keys['sk'])) === SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) return;
        $kp = sodium_crypto_sign_keypair();
        update_option(self::KEY_OPTION, [
            'sk' => base64_encode(sodium_crypto_sign_secretkey($kp)),
            'pk' => base64_encode(sodium_crypto_sign_publickey($kp)),
        ]);
        update_option(self::PUBKEY_OPTION, base64_encode(sodium_crypto_sign_publickey($kp)));
    }

    static function sign_payload($payload) {
        self::ensure_keypair();
        $keys = get_option(self::KEY_OPTION);
        if (!$keys || !isset($keys['sk'])) return self::legacy_sign($payload);
        $sk = base64_decode($keys['sk']);
        $json = wp_json_encode($payload);
        $sig = sodium_crypto_sign_detached($json, $sk);
        return base64_encode($json) . '.' . base64_encode($sig);
    }

    static function legacy_sign($payload) {
        self::ensure_token_secret();
        $secret = get_option('floki_token_secret');
        $json = wp_json_encode($payload);
        $sig = hash_hmac('sha256', $json, $secret);
        return base64_encode($json) . '.' . $sig;
    }

    static function rewrite() {
        add_rewrite_rule(
            '^app(?:/(.*))?/?$',
            'index.php?' . self::FLAG . '=1&' . self::PATH . '=$matches[1]',
            'top'
        );
    }

    static function vars($vars) {
        $vars[] = self::FLAG;
        $vars[] = self::PATH;
        return $vars;
    }

    static function canonical($redirect, $requested) {
        return (self::is_root() || get_query_var(self::FLAG))
            ? false
            : $redirect;
    }

    static function back_home() {
        wp_safe_redirect(home_url('/'));
        exit;
    }

    static function login_redirect($redirect, $requested, $user) {
        if (is_wp_error($user)) return $redirect;
        if (user_can($user, 'manage_options') && $requested && str_contains($requested, '/wp-admin')) {
            return $requested;
        }
        return home_url('/');
    }

    static function approve_admin_user($user_id) {
        if (!is_admin() || !current_user_can('create_users')) return;
        $user = get_userdata($user_id);
        if (!$user) return;
        $known = ['administrator', 'floki_admin', 'floki_operator', 'floki_user'];
        if (!array_intersect($known, (array) $user->roles)) {
            $user->set_role('floki_user');
        }
        update_user_meta($user_id, 'floki_account_status', 'approved');
    }

    static function remove_signup() {
        remove_shortcode('floki_application_form');
        add_shortcode('floki_application_form', '__return_empty_string');
    }

    static function register_routes() {
        register_rest_route('floki/v1', '/token', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'issue_token'],
            'permission_callback' => [__CLASS__, 'can_issue_token'],
        ]);
        register_rest_route('floki/v1', '/public-key', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_public_key'],
            'permission_callback' => '__return_true',
        ]);
    }

    static function can_issue_token() {
        $nonce = isset($_SERVER['HTTP_X_WP_NONCE']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_X_WP_NONCE'])) : '';
        if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) return false;
        return is_user_logged_in() && self::authorized();
    }

    static function issue_token() {
        $user = wp_get_current_user();
        if (!$user || !$user->ID) {
            return new WP_REST_Response(['error' => 'unauthorized'], 401);
        }
        $issued = time();
        $expires = $issued + 300;
        $payload = [
            'iss' => home_url('/'),
            'aud' => 'https://api.galactic-family-hub.com',
            'sub' => (string) $user->ID,
            'role' => implode(',', (array) $user->roles),
            'status' => get_user_meta($user->ID, 'floki_account_status', true) ?: 'approved',
            'iat' => $issued,
            'exp' => $expires,
            'nbf' => $issued,
            'jti' => bin2hex(random_bytes(12)),
            'v' => '1',
        ];
        $token = self::sign_payload($payload);
        return new WP_REST_Response([
            'token' => $token,
            'expires_at' => $expires * 1000,
        ], 200);
    }

    static function get_public_key() {
        $pubkey = get_option(self::PUBKEY_OPTION);
        if ($pubkey) {
            return new WP_REST_Response([
                'public_key' => $pubkey,
                'algorithm' => 'Ed25519',
            ], 200);
        }
        return new WP_REST_Response(['error' => 'no signing key configured'], 500);
    }

    static function is_root() {
        if (is_admin()) return false;
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        return is_string($path) && '/' . trim($path, '/') === '/';
    }

    static function authorized() {
        if (!is_user_logged_in()) return false;
        $user = wp_get_current_user();
        if (user_can($user, 'manage_options') || user_can($user, 'floki_manage_applications')) return true;
        if (!array_intersect(['floki_user', 'floki_operator', 'floki_admin'], (array) $user->roles)) return false;
        return get_user_meta($user->ID, 'floki_account_status', true) === 'approved';
    }

    static function content_type($file) {
        $map = [
            'html' => 'text/html; charset=UTF-8',
            'js' => 'text/javascript; charset=UTF-8',
            'mjs' => 'text/javascript; charset=UTF-8',
            'css' => 'text/css; charset=UTF-8',
            'json' => 'application/json; charset=UTF-8',
            'map' => 'application/json; charset=UTF-8',
            'svg' => 'image/svg+xml',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'ico' => 'image/x-icon',
            'woff' => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf',
        ];
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        return $map[$ext] ?? 'application/octet-stream';
    }

    static function send($file, $index = false) {
        if (!is_file($file) || !is_readable($file)) {
            status_header(404);
            exit;
        }
        if ($index) {
            $content = file_get_contents($file);
            $nonce = wp_create_nonce('wp_rest');
            $origin = 'https://api.galactic-family-hub.com';
            $token_url = rest_url('floki/v1/token');
            $bootstrap = '<script>window.FLOKI_BOOTSTRAP=' . wp_json_encode([
                'token_url' => $token_url,
                'api_origin' => $origin,
                'nonce' => $nonce,
                'refresh_ms' => 300000,
            ]) . ';</script>';
            $content = str_replace('</head>', $bootstrap . "\n</head>", $content);
            nocache_headers();
            header('X-Content-Type-Options: nosniff');
            header('Referrer-Policy: same-origin');
            header('Content-Type: text/html; charset=UTF-8');
            header('Cache-Control: no-store, max-age=0');
            echo $content;
            exit;
        }
        nocache_headers();
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('Content-Type: ' . self::content_type($file));
        header('Cache-Control: public, max-age=31536000, immutable');
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') {
            readfile($file);
        }
        exit;
    }

    static function app_root() {
        $dir = realpath(__DIR__ . '/app');
        if ($dir === false) wp_die('Floki web application files are missing.');
        return $dir;
    }

    static function login_error() {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || ($_POST['floki_login_action'] ?? '') !== 'sign_in') return '';
        $nonce = sanitize_text_field(wp_unslash($_POST['floki_login_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'floki_root_login')) return 'The sign-in request expired. Please try again.';
        $login = sanitize_text_field(wp_unslash($_POST['log'] ?? ''));
        $password = (string) ($_POST['pwd'] ?? '');
        if ($login === '' || $password === '') return 'Enter both your username and password.';
        $user = wp_signon([
            'user_login' => $login,
            'user_password' => $password,
            'remember' => isset($_POST['rememberme']),
        ], is_ssl());
        if (is_wp_error($user)) return 'The username or password was not accepted.';
        wp_safe_redirect(home_url('/'));
        exit;
    }

    static function login_page() {
        $error = self::login_error();
        status_header(200);
        nocache_headers();
        header('Content-Type: text/html; charset=UTF-8');
        ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark">
<title>Floki Neural Interface</title>
<style>
*{box-sizing:border-box}
body{
margin:0;min-height:100vh;display:grid;place-items:center;
background:radial-gradient(circle at 50% 15%,rgba(37,99,235,.18),transparent 38rem),#030712;
color:#e5eefb;font-family:system-ui,sans-serif}
.panel{
width:min(92vw,28rem);padding:2rem;
border:1px solid rgba(96,165,250,.25);
border-radius:1rem;background:rgba(8,15,30,.94);
box-shadow:0 1.5rem 4rem rgba(0,0,0,.45)}
h1{margin:0 0 .4rem;font-size:1.65rem}
.sub{margin:0 0 1.6rem;color:#93a4bb}
label{display:block;margin:.9rem 0 .4rem;font-weight:650}
input[type=text],input[type=password]{
width:100%;min-height:3rem;padding:.75rem .85rem;
border:1px solid #334155;border-radius:.65rem;
background:#0f172a;color:#f8fafc;font:inherit}
.rem{
display:flex;align-items:center;gap:.5rem;
margin:1rem 0;color:#cbd5e1}
button{
width:100%;min-height:3rem;border:0;border-radius:.65rem;
background:linear-gradient(135deg,#2563eb,#0ea5e9);
color:white;font:inherit;font-weight:750;cursor:pointer}
.err{
padding:.75rem;margin:0 0 1rem;
border:1px solid rgba(248,113,113,.45);
border-radius:.6rem;background:rgba(127,29,29,.28);
color:#fecaca}
.invite{
margin-top:1.2rem;color:#64748b;
font-size:.86rem;text-align:center}
</style>
</head>
<body>
<main class="panel">
<h1>Floki Neural Interface</h1>
<p class="sub">Private family access</p>
<?php if ($error !== '') : ?>
<div class="err"><?php echo esc_html($error); ?></div>
<?php endif; ?>
<form method="post" action="<?php echo esc_url(home_url('/')); ?>">
<?php wp_nonce_field('floki_root_login', 'floki_login_nonce'); ?>
<input type="hidden" name="floki_login_action" value="sign_in">
<label for="user_login">Username or email</label>
<input id="user_login" name="log" type="text" autocomplete="username" required autofocus>
<label for="user_pass">Password</label>
<input id="user_pass" name="pwd" type="password" autocomplete="current-password" required>
<label class="rem"><input name="rememberme" type="checkbox" value="forever"> Remember me</label>
<button type="submit">Sign in</button>
</form>
<p class="invite">Invite only. Accounts are created by the administrator.</p>
</main>
</body>
</html>
        <?php
        exit;
    }

    static function asset_route() {
        $requested = trim((string) get_query_var(self::PATH), '/');
        if ($requested === '') { wp_safe_redirect(home_url('/')); exit; }
        if (!self::authorized()) self::login_page();
        $root = self::app_root();
        $file = realpath($root . '/' . $requested);
        if ($file !== false && str_starts_with($file, $root . DIRECTORY_SEPARATOR) && is_file($file)) {
            self::send($file);
        }
        wp_safe_redirect(home_url('/'));
        exit;
    }

    static function serve() {
        if (get_query_var(self::FLAG)) { self::asset_route(); }
        if (!self::is_root()) return;
        if (!self::authorized()) {
            if (is_user_logged_in()) wp_logout();
            self::login_page();
        }
        self::send(self::app_root() . '/index.html', true);
    }
}

register_activation_hook(__FILE__, ['Floki_Neural_Web_App', 'activate']);
register_deactivation_hook(__FILE__, ['Floki_Neural_Web_App', 'deactivate']);
Floki_Neural_Web_App::boot();
